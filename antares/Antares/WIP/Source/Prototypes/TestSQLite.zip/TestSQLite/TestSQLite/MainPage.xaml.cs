﻿using eSECSync.Clients;
using SQLite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace TestSQLite
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            ZipManager zm = new ZipManager(ApplicationData.Current.LocalFolder);

            var zipfile = await zm.ArchiveFile(await ApplicationData.Current.LocalFolder.GetFileAsync("people.esec"));
                //await ApplicationData.Current.LocalFolder.GetFileAsync("Desktop.zip");

            await zm.ExtractArchiveFile(zipfile);

            //Person ps1 = new Person
            //{
            //    LastName = "Smith",
            //    Name = "Emi"    
            //};
            //Person ps2 = new Person
            //{
            //    LastName = "Le",
            //    Name = "Hung"
            //};

            //await PeopleAdapter.PeopleConnection.InsertAsync(ps1);
            //await PeopleAdapter.PeopleConnection.InsertAsync(ps2);
            //await PeopleAdapter.PeopleConnection.DeleteAsync(ps2);

            //var result = await PeopleAdapter.PeopleConnection.QueryAsync<Person>("select * from Person", "");

            //var query = PeopleAdapter.PeopleConnection.Table<Person>().Where(p => (p.LastName == "Smith" && p.Name == "Emi"));
            //var result2 = await query.ToListAsync();

            //LiveAuthClient auth = new LiveAuthClient();
            //LiveLoginResult loginResult = await auth.LoginAsync(new string[] { "wl.basic", "wl.contacts_skydrive", "wl.skydrive_update" });
            //if (loginResult.Status == LiveConnectSessionStatus.Connected)
            //{
            //    LiveConnectClient connect = new LiveConnectClient(auth.Session);
            //    LiveOperationResult operationResult = await connect.GetAsync("me");
            //    dynamic result = operationResult.Result;
            //    if (result != null)
            //    {
            //        this.infoTextBlock.Text = string.Join(" ", "Hello", result.name, "!");

            //        var folderData = new Dictionary<string, object>();
            //        folderData.Add("name", "eSEC");
            //        var b = await connect.GetAsync("me/skydrive/my_documents/files");

            //        result = b.Result;

            //        if (result == null)
            //        {
            //            return;
            //        }

            //        foreach (var item in result.data)
            //        {
            //            if (item.name == "eSEC" && item.type == "folder")
            //            {
            //                Windows.Storage.StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync("people.zip");
            //                if (file != null)
            //                {
            //                    var progressHandler = new Progress<LiveOperationProgress>(
            //                        (progress) => 
            //                        { 
            //                            UploadProgressBar.Value = progress.ProgressPercentage; 
            //                        });
            //                    this.ctsUpload = new System.Threading.CancellationTokenSource();
            //                    await connect.BackgroundUploadAsync(item.id.ToString(),
            //                        file.Name, file, OverwriteOption.Overwrite, this.ctsUpload.Token, progressHandler);
            //                    this.infoTextBlock.Text = "Upload completed.";
            //                }
            //            }
            //        }
            //    }
            //    else
            //    {
            //        this.infoTextBlock.Text = "Error getting name.";
            //    }

            //}
        }

        private double percent = 0;
        private System.Threading.CancellationTokenSource ctsUpload;
    }

    public static class PeopleAdapter
    {
        public static SQLiteAsyncConnection PeopleConnection { get; private set; }

        public static async Task CreateDatabase()
        {
            //PeopleConnection = new SQLiteAsyncConnection("people.esec");
            //await PeopleConnection.CreateTableAsync<Person>();
        }
    }

    public class Person
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }

        [MaxLength(30)]
        public string Name { get; set; }

        [MaxLength(30)]
        public string LastName { get; set; }
    }
}
