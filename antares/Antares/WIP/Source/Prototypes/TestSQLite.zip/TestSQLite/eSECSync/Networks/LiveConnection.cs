﻿using eSECSync.Clients;
using Microsoft.Live;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace eSECSync.Networks
{
    public class LiveConnection
    {
        private LiveConnectClient _liveConnectClient;
        private ZipManager _zipManager = new ZipManager();

        public static LiveConnection Instance
        {
            get
            {
                return Nested._instance;
            }
        }

        private class Nested
        {
            internal static readonly LiveConnection _instance = new LiveConnection();
        }

        /// <summary>
        /// Create connection with scope Basic, SkyDrive.
        /// </summary>
        /// <returns>Return true if connect successful. Otherwise, return false.</returns>
        public async Task<bool> CreateConnectionAsync()
        {
            try
            {
                LiveAuthClient auth = new LiveAuthClient();
                LiveLoginResult loginResult = await auth.LoginAsync(new string[] { "wl.basic", "wl.contacts_skydrive", "wl.skydrive_update" });

                if (loginResult.Status == LiveConnectSessionStatus.Connected)
                {
                    _liveConnectClient = new LiveConnectClient(loginResult.Session);
                    return true;
                }

                return false;
            }
            catch
            {
                return false;
            }
        }

        private double percent = 0;
        private System.Threading.CancellationTokenSource ctsUpload;

        /// <summary>
        /// Download content to Downloads folder.
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public async Task<bool> UploadDataAsync()
        {
            //dynamic documentFiles = (await _liveConnectClient.GetAsync("me/skydrive/my_documents/files")).Result;

            //if (documentFiles == null)
            //{
            //    return false;
            //}

            //foreach (var item in documentFiles.data)
            //{
            //    if (item.name == "eSEC")
            //    {
            //        var file = await _zipManager.ArchiveFile(await ApplicationData.Current.LocalFolder.GetFileAsync("people.esec"));

            //        if (file != null)
            //        {
            //            var progressHandler = new Progress<LiveOperationProgress>(
            //                (progress) =>
            //                {
            //                    percent = progress.ProgressPercentage;
            //                });
            //            this.ctsUpload = new System.Threading.CancellationTokenSource();
            //            await _liveConnectClient.BackgroundUploadAsync(item.id.ToString(),
            //                file.Name, file, OverwriteOption.Overwrite, this.ctsUpload.Token, progressHandler);

            //            return true;
            //        }
            //    }
            //}

            return false;
        }
    }
}
