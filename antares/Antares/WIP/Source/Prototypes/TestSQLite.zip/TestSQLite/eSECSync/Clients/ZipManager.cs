﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.Storage.Streams;

namespace eSECSync.Clients
{
    public class ZipManager
    {
        private StorageFolder _destinationFolder;

        public ZipManager()
        {
        }

        public ZipManager(StorageFolder destinationFolder)
        {
            _destinationFolder = destinationFolder;
        }

        /// <summary>
        /// Create a file the current folder provided the file relative path. If file exists, it will be replaced.
        /// </summary>
        /// <param name="fileName">Name of the file in the folder, the file can reside in a sub folder of the current folder.</param>
        /// <param name="rootFolder">The current folder.</param>
        /// <returns>A StorageFile of the newly created file.</returns>
        private async Task<StorageFile> CreateFile(string fileName, StorageFolder rootFolder)
        {
            rootFolder = await CreateFolder(Path.GetDirectoryName(fileName), rootFolder);
            return await rootFolder.CreateFileAsync(Path.GetFileName(fileName), CreationCollisionOption.ReplaceExisting);
        }

        /// <summary>
        /// Create a folder in the current rootFolder.
        /// </summary>
        /// <param name="folderName">Name of the folder to be created. This does not have to be an immediate sub-folder of the current folder.</param>
        /// <param name="rootFolder">The current folder.</param>
        /// <returns>None.</returns>
        private async Task<StorageFolder> CreateFolder(string folderName, StorageFolder rootFolder)
        {
            if (string.IsNullOrEmpty(folderName))
            {
                return rootFolder;
            }

            int startIndex = folderName.IndexOf('\\');

            if (startIndex == -1)
            {
                return await rootFolder.CreateFolderAsync(folderName, CreationCollisionOption.OpenIfExists);
            }

            rootFolder = await rootFolder.CreateFolderAsync(folderName.Substring(0, startIndex), CreationCollisionOption.OpenIfExists);
            folderName = folderName.Substring(startIndex + 1);
            return await CreateFolder(folderName, rootFolder);
        }

        public async Task<StorageFile> ArchiveFile(StorageFile file, string zipName = null)
        {
            if(zipName == null)
            {
                zipName = file.Name.Replace(".esec", ".zip");
            }

            var readStream = await file.OpenAsync(FileAccessMode.Read);

            var inputStream = readStream.GetInputStreamAt(0);
            var dataReader = new DataReader(inputStream);

            var numBytesLoaded = await dataReader.LoadAsync((uint)readStream.Size);
            var content = dataReader.ReadString(numBytesLoaded);

            dataReader.DetachStream();
            dataReader.Dispose();
            inputStream.Dispose();
            readStream.Dispose();

            var zipMemoryStreams = new MemoryStream();
            ZipArchive archive = new ZipArchive(zipMemoryStreams, ZipArchiveMode.Create);


            var entry = archive.CreateEntry(file.Name);
            using (StreamWriter writer = new StreamWriter(entry.Open()))
            {
                await writer.WriteAsync(content);
            }

            var zipFile = await ApplicationData.Current.LocalFolder.CreateFileAsync(zipName);
            var stream = await zipFile.OpenStreamForWriteAsync();
            await zipMemoryStreams.CopyToAsync(stream);

            return zipFile;
        }

        public async Task<bool> ExtractArchiveFile(StorageFile zipFile)
        {
            using (var zipStream = await zipFile.OpenStreamForReadAsync())
            {
                using (var zipMemoryStreams = new MemoryStream((int)zipStream.Length))
                {
                    await zipStream.CopyToAsync(zipMemoryStreams);
                    try
                    {
                        using (var archive = new ZipArchive(zipMemoryStreams, ZipArchiveMode.Read))
                        {
                            foreach (var entry in archive.Entries)
                            {
                                if (!string.IsNullOrEmpty(entry.Name))
                                {
                                    using (var fileData = entry.Open())
                                    {
                                        var outputFile = await CreateFile(entry.FullName, _destinationFolder);
                                        using (var outputFileStream = await outputFile.OpenStreamForWriteAsync())
                                        {
                                            await fileData.CopyToAsync(outputFileStream);
                                            await outputFileStream.FlushAsync();
                                        }
                                    }
                                }
                            }
                        }

                        return true;
                    }
                    catch (Exception ex)
                    {
                        return false;
                    }
                }
            }
        }
    }
}
